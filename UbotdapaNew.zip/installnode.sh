curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
 apt-get install -y nodejs
 